# Mario Kart 8 – Statistics
## Source
 * http://i.imgur.com/WwqJF4O.png